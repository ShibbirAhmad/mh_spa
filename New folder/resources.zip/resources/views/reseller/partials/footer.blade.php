<footer>
    <div class="pull-right">
        <p>All Right Received Mohasagor.com</p>
    </div>
    <div class="clearfix"></div>
</footer>
