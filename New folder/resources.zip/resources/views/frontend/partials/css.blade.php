<!-- CSS Part Start-->
<link rel="stylesheet" type="text/css" href="{{asset('frontend/js/bootstrap/css/bootstrap.min.css')}}" />
<link rel="stylesheet" type="text/css" href="{{asset('frontend/css/font-awesome/css/font-awesome.min.css')}}"/>
<link rel="stylesheet" type="text/css" href="{{asset('frontend/css/stylesheet.css')}}" />
{{-- <link rel="stylesheet" type="text/css" href="{{asset('frontend/css/owl.carousel.css')}}" /> --}}
<link rel="stylesheet" type="text/css" href="{{asset('frontend/css/owl.transitions.css')}}"/>
<link rel="stylesheet" type="text/css" href="{{asset('frontend/css/responsive.css')}}"/>
<link rel="stylesheet" type="text/css" href="{{asset('frontend/css/stylesheet-skin3.css')}}"/>
<link href='//fonts.googleapis.com/css?family=Droid+Sans' rel='stylesheet' type='text/css'>
<link rel="stylesheet" type="text/css" href="{{asset('frontend/css/scrol.css')}}"/>
<link rel="stylesheet" href="{{ asset('admin/css/sweetalert2.css') }}">
<link rel="stylesheet" type="text/css" href="{{asset('frontend/css/customize.css')}}"/>
<link rel="stylesheet" type="text/css" href="{{asset('frontend/css/header.css')}}"/>


{{-- <script type="text/javascript" src="{{asset('frontend/js/jquery-2.1.1.min.js')}}"></script> --}}
<script src="{{asset('admin/js/objectToFormData.js')}}"></script>


{{-- <script type="text/javascript" src="{{asset('frontend/js/custome.js')}}"></script> --}}
<script src="{{ asset('admin/js/sweetalert2.all.js') }}"></script>